<?php $__env->startSection('title'); ?>
    Admin Panel
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    Anasayfa
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mustafa\Code\keto\resources\views/back/index.blade.php ENDPATH**/ ?>