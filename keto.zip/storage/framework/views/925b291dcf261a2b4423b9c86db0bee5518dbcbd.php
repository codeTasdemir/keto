<footer class="main-footer">
    <strong>Copyright by Deneme &copy; 2022 </strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">

    </div>
</footer>
<?php /**PATH C:\Users\Mustafa\Code\keto\resources\views/back/partials/footer.blade.php ENDPATH**/ ?>