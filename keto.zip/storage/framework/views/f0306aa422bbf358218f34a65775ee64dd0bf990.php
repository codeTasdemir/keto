
<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary elevation-4">

    <div class="sidebar">

        <div class="user-panel mt-3 pb-3 mb-3 d-flex">
            <div class="info">
                <p class="text-white lead"><?php if(Auth::check()): ?> <?php echo e(Auth::user()->name); ?> <?php endif; ?></p>
            </div>
        </div>
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

                <li class="nav-item">
                    <a href="<?php echo e(route('panel.index')); ?>" class="nav-link">
                        <i class="nav-icon fas fa-home"></i>
                        <p>
                            Anasayfa
                        </p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-copy"></i>
                        <p>
                            Besinler
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('calorie.create')); ?>" class="nav-link">
                                <p>Besin Ekle</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('calories')); ?>" class="nav-link">
                                <p>Besin Listesi</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-copy"></i>
                        <p>
                            Müşteriler
                            <i class="fas fa-angle-left right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('onlineCustomer')); ?>" class="nav-link">
                                <p>Online Diet Talepleri</p>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
        <!-- /.sidebar-menu -->
    </div>
</aside>
<?php /**PATH C:\Users\Mustafa\Code\keto\resources\views/back/partials/sidebar.blade.php ENDPATH**/ ?>