<?php $__env->startSection('title'); ?>
Online Diyet Talepleri
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <table id="table_id" class="table">
                            <thead>
                            <tr>
                                <th scope="col">Ad</th>
                                <th scope="col">Soyad</th>
                                <th scope="col">Cinsiyet</th>
                                <th scope="col"></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($customer->name); ?></th>
                                <td><?php echo e($customer->lastName); ?></td>
                                <td><?php echo e($customer->gender); ?></td>
                                <td><a href="<?php echo e(route('customer.detail',$customer->slug)); ?>" class="btn btn-warning">Detayı Görüntüle</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('back.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mustafa\Code\keto\resources\views/back/pages/Customer/Customers.blade.php ENDPATH**/ ?>