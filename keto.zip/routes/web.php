<?php
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\back\PanelIndexControlerr;
use App\Http\Controllers\back\CalorieController;
use App\Http\Controllers\back\CustomerController;

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
Route::get('/', function (){return view('index');});

Route::prefix('panel')->middleware('auth')->group(function(){
    Route::get('/',[PanelIndexControlerr::class,'index'])->name('panel.index');
    Route::get('/kaloriler',[CalorieController::class,'index'])->name('calories');
    Route::get('/kalori-ekle',[CalorieController::class,'create'])->name('calorie.create');
    Route::post('/kalori-ekle',[CalorieController::class,'store'])->name('calorie.store');
    Route::post('/kalori-sil/{id}',[CalorieController::class,'delete'])->name('calorie.delete');
    Route::get('/kalori-düzenle/{id}',[CalorieController::class,'edit'])->name('calorie.edit');
    Route::post('/kalori-güncelle/{id}',[CalorieController::class,'update'])->name('calorie.update');

    Route::get('/online-diyet-talepleri',[CustomerController::class,'BackIndex'])->name('onlineCustomer');
    Route::get('/online-diyet-müşteri-detayı/{slug}',[CustomerController::class,'show'])->name('customer.detail');
    Route::get('/Diet-liste-hazırla/{slug}',[CustomerController::class,'ShowDietListForm'])->name('customer.CreateDietList');


});

    Route::get('/online-diyet-basvuru',[CustomerController::class,'FrontIndex'])->name('onlineDietForm');
    Route::post('/online-diyet-basvuru-kayıt',[CustomerController::class,'store'])->name('customer.store');




