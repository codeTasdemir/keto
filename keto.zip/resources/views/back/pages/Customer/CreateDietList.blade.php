@extends('back.layouts.master')
@section('title')
Diyet Listesi Oluştur
@endsection
@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">

            </div>
        </div>

    </div>

@endsection
