@extends('back.layouts.master')
@section('title')
    Admin Panel
@endsection
@section('content')
    Anasayfa
@endsection
