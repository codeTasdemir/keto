<footer class="main-footer">
    <strong>Copyright by Deneme &copy; 2022 </strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">

    </div>
</footer>
